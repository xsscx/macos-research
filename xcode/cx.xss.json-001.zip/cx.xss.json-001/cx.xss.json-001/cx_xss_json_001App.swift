//
//  cx_xss_json_001App.swift
//  cx.xss.json-001
//
//  Created by D Hoyt on 8/16/21.
//

import SwiftUI

@main
struct cx_xss_json_001App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
